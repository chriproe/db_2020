--9
SELECT 
  *
FROM
  Visit
WHERE
  NFC_ID = '1'
ORDER BY (VisitStartDate) ASC ;
